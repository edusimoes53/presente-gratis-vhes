# Guia do Desenvolvedor - App Free Gift Buy X Get Y

## Visão Geral da Arquitetura

O app Free Gift Buy X Get Y foi desenvolvido usando as seguintes tecnologias:

- **Frontend**: Next.js, React 18, TypeScript, Tailwind CSS
- **Backend**: Node.js, Express
- **APIs Shopify**: Storefront API, Admin API
- **Armazenamento**: Banco de dados da loja Shopify

A arquitetura do app é composta por:

1. **Interface de Administração**: Painel para configuração de regras de promoção
2. **Motor de Regras**: Lógica central para processamento das regras de promoção
3. **Integração com Carrinho**: Componentes para monitorar e modificar o carrinho
4. **Armazenamento de Dados**: Sistema para persistir as regras e configurações

## Estrutura de Diretórios

```
shopify-free-gift-app/
├── src/
│   ├── components/
│   │   ├── admin/           # Componentes da interface de administração
│   │   │   ├── AdminDashboard.tsx
│   │   │   ├── ProductSelector.tsx
│   │   │   ├── RuleForm.tsx
│   │   │   └── RuleList.tsx
│   │   └── cart/            # Componentes de integração com o carrinho
│   │       ├── CartManager.tsx
│   │       └── CartMonitor.tsx
│   ├── lib/                 # Bibliotecas e utilitários
│   │   ├── cartIntegration.ts
│   │   ├── ruleEngine.ts
│   │   └── types.ts
│   ├── pages/               # Páginas do Next.js
│   │   ├── _app.tsx
│   │   ├── admin.tsx
│   │   └── index.tsx
│   └── tests/               # Testes automatizados
│       ├── cartIntegration.test.ts
│       └── ruleEngine.test.ts
├── docs/                    # Documentação
│   ├── arquitetura.md
│   ├── guia_instalacao.md
│   ├── manual_usuario.md
│   └── todo.md
├── public/                  # Arquivos estáticos
├── jest.config.js           # Configuração de testes
└── package.json             # Dependências e scripts
```

## Fluxo de Dados

1. **Configuração de Regras**:
   - Lojista configura regras através da interface de administração
   - Regras são salvas no banco de dados da loja

2. **Monitoramento do Carrinho**:
   - O app monitora eventos de adição/remoção de itens no carrinho
   - Quando um evento é detectado, o motor de regras é acionado

3. **Processamento de Regras**:
   - O motor de regras verifica se alguma regra é aplicável ao estado atual do carrinho
   - Determina quais produtos gratuitos devem ser adicionados ou removidos

4. **Modificação do Carrinho**:
   - O app utiliza a Storefront API para adicionar ou remover produtos do carrinho
   - Produtos gratuitos são marcados com metadados especiais

## Principais Componentes

### Motor de Regras (`ruleEngine.ts`)

O motor de regras é o componente central que implementa a lógica de negócio do app. Ele contém funções para:

- Verificar se uma regra é aplicável ao estado atual do carrinho
- Determinar quais produtos gratuitos devem ser adicionados
- Identificar quais produtos gratuitos devem ser removidos

### Integração com Carrinho (`cartIntegration.ts`)

Este componente gerencia a comunicação com a API Shopify para:

- Monitorar eventos do carrinho
- Adicionar produtos gratuitos ao carrinho
- Remover produtos gratuitos quando as condições não são mais atendidas

### Interface de Administração (`AdminDashboard.tsx`)

A interface de administração permite ao lojista:

- Visualizar todas as regras configuradas
- Criar novas regras de promoção
- Editar ou excluir regras existentes
- Ativar ou desativar regras

## Integração com a API Shopify

### Storefront API

Usada para:
- Obter informações do carrinho atual
- Adicionar ou remover itens do carrinho
- Aplicar metadados aos itens do carrinho

### Admin API

Usada para:
- Gerenciar regras de promoção
- Acessar informações de produtos
- Configurar webhooks para eventos da loja

## Personalização e Extensão

### Adicionando Novos Tipos de Regras

Para adicionar novos tipos de regras:

1. Estenda a interface `Rule` em `types.ts`
2. Adicione a lógica correspondente em `ruleEngine.ts`
3. Atualize a interface de administração para suportar o novo tipo de regra

### Personalização da Interface

A interface do app usa Tailwind CSS, facilitando a personalização:

1. Modifique as classes CSS nos componentes React
2. Ajuste o tema Tailwind em `tailwind.config.js`
3. Adicione novos componentes conforme necessário

## Considerações de Desempenho

- O app foi projetado para minimizar o impacto no desempenho da loja
- O processamento de regras é otimizado para lidar com grandes volumes de produtos
- Recomenda-se limitar o número de regras ativas simultaneamente para melhor desempenho

## Segurança

- Todas as interações com a API Shopify são autenticadas
- Os dados do cliente são processados de acordo com as políticas de privacidade da Shopify
- O app não armazena informações sensíveis de pagamento

## Testes

O app inclui testes automatizados para:

- Verificar o funcionamento correto do motor de regras
- Testar a integração com o carrinho
- Validar o comportamento em diferentes cenários

Para executar os testes:

```bash
npm test
```

## Implantação

Para implantar o app em produção:

1. Configure as credenciais da API Shopify
2. Execute o build de produção:
   ```bash
   npm run build
   ```
3. Implante os arquivos gerados em um servidor compatível com Node.js

## Suporte e Contribuição

Para contribuir com o desenvolvimento do app:

1. Faça um fork do repositório
2. Implemente suas alterações
3. Envie um pull request com uma descrição detalhada das mudanças

Para relatar problemas ou solicitar recursos:

- Abra uma issue no repositório do GitHub
- Entre em contato com a equipe de desenvolvimento

---

Este guia do desenvolvedor é destinado a facilitar a compreensão, manutenção e extensão do app Free Gift Buy X Get Y.
