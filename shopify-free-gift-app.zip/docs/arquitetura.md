# Arquitetura do App Free Gift Buy X Get Y para Shopify

## Visão Geral
O app "Free Gift Buy X Get Y" permitirá que lojistas configurem promoções onde, quando um cliente adiciona um determinado produto (ou produtos) ao carrinho em uma quantidade mínima específica, outro produto (ou produtos) será automaticamente adicionado como brinde.

## Componentes Principais

### 1. Interface de Administração
- **Painel de Configuração**: Interface onde o lojista poderá configurar as regras de promoção.
- **Gerenciador de Regras**: Permitirá criar, editar, ativar/desativar e excluir regras de promoção.
- **Visualizador de Estatísticas**: Mostrará dados sobre o uso das promoções.

### 2. Mecanismo de Regras
- **Processador de Condições**: Avaliará se as condições para adicionar um brinde foram atendidas.
- **Gerenciador de Produtos**: Permitirá selecionar quais produtos ativam a promoção e quais serão adicionados como brinde.
- **Configurador de Quantidades**: Definirá a quantidade mínima necessária para ativar a promoção.

### 3. Integração com Carrinho
- **Detector de Eventos**: Monitorará eventos de adição/remoção de produtos no carrinho.
- **Manipulador de Carrinho**: Adicionará automaticamente os produtos de brinde quando as condições forem atendidas.
- **Sincronizador de Estado**: Garantirá que os brindes sejam removidos quando os produtos qualificadores forem removidos.

### 4. Armazenamento de Dados
- **Banco de Dados de Regras**: Armazenará as configurações de todas as regras de promoção.
- **Cache de Sessão**: Manterá o estado do carrinho e das promoções ativas durante a sessão do cliente.
- **Registro de Atividades**: Armazenará logs de atividades para análise e depuração.

## Fluxo de Funcionamento

1. **Configuração**:
   - O lojista acessa o painel de administração do app.
   - Configura uma nova regra especificando:
     - Produto(s) qualificador(es)
     - Quantidade mínima necessária
     - Produto(s) a ser(em) adicionado(s) como brinde
     - Período de validade da promoção (opcional)
   - Salva e ativa a regra.

2. **Execução**:
   - Cliente navega na loja e adiciona produtos ao carrinho.
   - Quando um produto qualificador é adicionado ao carrinho:
     - O app verifica se a quantidade mínima foi atingida.
     - Se sim, adiciona automaticamente o produto de brinde ao carrinho.
   - Se o cliente remover ou reduzir a quantidade do produto qualificador:
     - O app verifica se a condição ainda é válida.
     - Se não, remove automaticamente o produto de brinde.

3. **Monitoramento**:
   - O lojista pode visualizar estatísticas sobre o uso das promoções.
   - Pode ajustar as regras conforme necessário para otimizar as conversões.

## Tecnologias

### Frontend
- **React/Remix**: Para a interface de administração e componentes de UI.
- **Polaris**: Biblioteca de componentes UI da Shopify para manter a consistência visual.
- **GraphQL**: Para comunicação eficiente com a API da Shopify.

### Backend
- **Node.js**: Ambiente de execução para o servidor.
- **Express**: Framework web para gerenciar rotas e requisições.
- **Prisma**: ORM para interação com o banco de dados.
- **SQLite**: Banco de dados para armazenamento local durante desenvolvimento.

### Integração Shopify
- **Shopify CLI**: Para desenvolvimento e testes locais.
- **Storefront API**: Para manipulação do carrinho e produtos.
- **Admin API**: Para acesso aos dados da loja e configurações.
- **Webhooks**: Para receber notificações de eventos da loja.

## Considerações de Segurança
- Autenticação OAuth para acesso seguro à API da Shopify.
- Validação de entrada para prevenir injeção de dados maliciosos.
- Limitação de taxa para prevenir abuso da API.
- Armazenamento seguro de tokens e dados sensíveis.

## Escalabilidade
- Arquitetura modular para facilitar a manutenção e expansão.
- Uso de cache para reduzir chamadas à API e melhorar o desempenho.
- Processamento assíncrono para operações demoradas.
- Monitoramento de desempenho para identificar gargalos.

## Próximos Passos
1. Configurar o ambiente de desenvolvimento com Shopify CLI.
2. Criar a estrutura básica do app usando o template Remix.
3. Implementar o modelo de dados para as regras de promoção.
4. Desenvolver a interface de administração para configuração de regras.
5. Implementar a lógica de detecção e manipulação do carrinho.
6. Testar o app em diferentes cenários.
7. Preparar documentação e instruções de uso.
