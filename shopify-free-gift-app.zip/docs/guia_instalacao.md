# Guia de Instalação - App Free Gift Buy X Get Y

## Requisitos do Sistema

- Loja Shopify ativa (plano Basic, Shopify ou Advanced)
- Acesso de administrador à loja
- Navegador web moderno (Chrome, Firefox, Safari ou Edge)

## Processo de Instalação

### Método 1: Instalação via Shopify App Store

1. Acesse a [Shopify App Store](https://apps.shopify.com/)
2. Pesquise por "Free Gift Buy X Get Y"
3. Clique no app nos resultados da pesquisa
4. Clique no botão "Adicionar app"
5. Faça login na sua conta Shopify, se solicitado
6. Revise as permissões solicitadas pelo app
7. Clique em "Instalar app"
8. Aguarde a conclusão da instalação

### Método 2: Instalação Manual (App Privado)

1. Faça o download do arquivo ZIP do app
2. Extraia o conteúdo do arquivo ZIP
3. Acesse o painel administrativo da sua loja Shopify
4. Navegue até "Apps" > "Gerenciar apps"
5. Clique em "Fazer upload de app"
6. Selecione o arquivo principal do app extraído
7. Siga as instruções na tela para concluir a instalação
8. Conceda as permissões necessárias quando solicitado

## Permissões Necessárias

O app solicitará as seguintes permissões:

- **Leitura de produtos**: Para acessar informações sobre seus produtos
- **Escrita de produtos**: Para marcar produtos como brindes
- **Leitura de pedidos**: Para analisar pedidos e verificar regras aplicadas
- **Leitura/Escrita de scripts**: Para modificar o comportamento do carrinho
- **Leitura/Escrita de temas**: Para integrar notificações ao tema da loja

## Configuração Pós-Instalação

Após a instalação bem-sucedida, você precisará:

1. Acessar o app através do painel administrativo da Shopify
2. Completar a configuração inicial
3. Criar sua primeira regra de promoção

## Verificação da Instalação

Para verificar se o app foi instalado corretamente:

1. Crie uma regra de teste simples
2. Navegue até sua loja como cliente
3. Adicione os produtos qualificadores ao carrinho
4. Verifique se o produto gratuito é adicionado automaticamente

## Desinstalação

Se você precisar desinstalar o app:

1. Acesse o painel administrativo da Shopify
2. Navegue até "Apps" > "Gerenciar apps"
3. Localize o app "Free Gift Buy X Get Y"
4. Clique em "Desinstalar"
5. Confirme a desinstalação

**Nota**: A desinstalação do app removerá todas as regras de promoção configuradas. Recomendamos fazer backup das configurações antes de desinstalar.

## Solução de Problemas de Instalação

### O app não aparece após a instalação

- Limpe o cache do navegador
- Faça logout e login novamente no painel administrativo da Shopify
- Verifique se você tem permissões de administrador

### Erro de permissões durante a instalação

- Verifique se você está logado como administrador da loja
- Tente instalar o app novamente
- Se o problema persistir, entre em contato com o suporte

### Conflitos com outros apps

Se você notar conflitos com outros apps após a instalação:

1. Desative temporariamente os outros apps
2. Teste o Free Gift Buy X Get Y
3. Reative os outros apps um por um para identificar o conflito

## Atualização do App

O app será atualizado automaticamente quando novas versões forem lançadas. Você será notificado sobre atualizações importantes que exijam ação da sua parte.

## Suporte Técnico

Se você encontrar problemas durante a instalação ou configuração:

- Consulte a documentação completa em nosso site
- Entre em contato com nosso suporte técnico
- Envie um e-mail para support@freegiftapp.com

---

Após a instalação, consulte o Manual do Usuário para aprender a configurar e usar todas as funcionalidades do app.
