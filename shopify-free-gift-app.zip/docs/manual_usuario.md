# Manual do Usuário - App Free Gift Buy X Get Y

## Visão Geral

O app Free Gift Buy X Get Y permite que você configure promoções onde, quando um cliente adiciona determinados produtos ao carrinho em uma quantidade mínima específica, outros produtos são automaticamente adicionados como brinde.

Este app é ideal para:
- Aumentar o valor médio do pedido
- Promover novos produtos
- Incentivar a compra de produtos específicos
- Oferecer brindes sazonais ou promocionais
- Melhorar a experiência de compra do cliente

## Instalação

1. Faça o download do arquivo ZIP do app
2. Acesse o painel administrativo da sua loja Shopify
3. Navegue até "Apps" > "Gerenciar apps"
4. Clique em "Fazer upload de app"
5. Selecione o arquivo ZIP baixado
6. Siga as instruções na tela para concluir a instalação
7. Conceda as permissões necessárias quando solicitado

## Configuração Inicial

Após a instalação, você precisará configurar o app:

1. Acesse o app através do painel administrativo da Shopify
2. Na primeira execução, você será direcionado para a página de configuração
3. Configure as permissões de acesso à API da sua loja
4. Salve as configurações

## Criando Regras de Promoção

Para criar uma nova regra de promoção:

1. No painel do app, clique no botão "Nova Regra"
2. Preencha os seguintes campos:
   - **Nome da Regra**: Um nome descritivo para identificar a promoção
   - **Status**: Ative ou desative a regra
   - **Quantidade Mínima**: Número mínimo de produtos qualificadores necessários
   - **Data de Início/Término**: Período de validade da promoção (opcional)
   - **Produtos Qualificadores**: Produtos que, quando adicionados ao carrinho, ativam a promoção
   - **Produtos Gratuitos**: Produtos que serão adicionados automaticamente como brinde

3. Clique em "Salvar Regra" para ativar a promoção

## Gerenciando Regras Existentes

No painel principal do app, você pode:

- **Visualizar** todas as regras de promoção existentes
- **Editar** regras clicando no botão "Editar"
- **Ativar/Desativar** regras sem excluí-las
- **Excluir** regras que não são mais necessárias

## Exemplos de Uso

### Exemplo 1: Compre 2, Ganhe 1

**Cenário**: Quando um cliente compra 2 camisetas, ganha 1 boné grátis.

**Configuração**:
- Nome: "Compre 2 Camisetas, Ganhe 1 Boné"
- Quantidade Mínima: 2
- Produtos Qualificadores: Selecione as camisetas elegíveis
- Produtos Gratuitos: Selecione o boné que será oferecido como brinde

### Exemplo 2: Promoção Sazonal

**Cenário**: Durante o mês de dezembro, quando um cliente compra qualquer produto acima de R$100, ganha um brinde de Natal.

**Configuração**:
- Nome: "Brinde de Natal"
- Quantidade Mínima: 1
- Produtos Qualificadores: Selecione os produtos elegíveis
- Produtos Gratuitos: Selecione o brinde de Natal
- Data de Início/Término: 01/12 a 31/12

## Comportamento no Carrinho

Quando um cliente adiciona produtos ao carrinho:

1. O app verifica automaticamente se alguma regra de promoção é aplicável
2. Se uma regra for aplicável, o produto gratuito é adicionado automaticamente ao carrinho
3. O cliente verá o produto gratuito no carrinho com preço zero
4. Se o cliente remover ou reduzir a quantidade dos produtos qualificadores abaixo do mínimo, o brinde será removido automaticamente

## Personalização

O app se integra perfeitamente ao tema da sua loja Shopify. Você pode personalizar:

- As mensagens exibidas quando um brinde é adicionado
- A aparência dos produtos gratuitos no carrinho
- As notificações para os clientes

## Solução de Problemas

### O produto gratuito não está sendo adicionado

Verifique:
- Se a regra está ativa
- Se a quantidade mínima de produtos qualificadores foi atingida
- Se o produto gratuito está disponível em estoque
- Se as datas de início/término da promoção estão corretas

### O produto gratuito não é removido quando deveria

Verifique:
- Se o produto foi adicionado pelo app (e não manualmente pelo cliente)
- Se o tema da sua loja é compatível com o app

### Conflitos com outros apps

Se você estiver usando outros apps que modificam o comportamento do carrinho, pode haver conflitos. Nesse caso:

1. Desative temporariamente os outros apps
2. Teste o Free Gift Buy X Get Y
3. Reative os outros apps um por um para identificar o conflito

## Suporte

Se você encontrar problemas ou tiver dúvidas:

- Consulte a documentação completa em nosso site
- Entre em contato com nosso suporte técnico
- Envie um e-mail para support@freegiftapp.com

## Atualizações

O app será atualizado regularmente com novos recursos e melhorias. As atualizações serão instaladas automaticamente, e você será notificado sobre mudanças importantes.

---

Obrigado por escolher o Free Gift Buy X Get Y para sua loja Shopify!
