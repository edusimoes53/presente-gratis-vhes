import { useEffect } from 'react';
import { useFreeGiftManager } from '../../lib/cartIntegration';
import { Rule } from '../../lib/types';

interface CartManagerProps {
  rules: Rule[];
}

export function CartManager({ rules }: CartManagerProps) {
  const { isProcessing } = useFreeGiftManager(rules);

  useEffect(() => {
    // Adicionar script para monitorar eventos do carrinho
    const script = document.createElement('script');
    script.innerHTML = `
      document.addEventListener('DOMContentLoaded', function() {
        // Monitorar eventos de adição/remoção de itens do carrinho
        document.addEventListener('cart:updated', function(event) {
          // Disparar evento personalizado para nosso app processar
          document.dispatchEvent(new CustomEvent('freegift:process'));
        });
      });
    `;
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <div className="free-gift-manager" style={{ display: 'none' }}>
      {/* Este componente não renderiza nada visualmente, apenas gerencia a lógica */}
      {isProcessing && <span id="processing-status">Processando brindes...</span>}
    </div>
  );
}

export function CartNotification({ message }: { message: string }) {
  if (!message) return null;
  
  return (
    <div className="fixed bottom-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded shadow-md">
      <div className="flex items-center">
        <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
        </svg>
        <p>{message}</p>
      </div>
    </div>
  );
}
