import { useState } from 'react';
import { Rule, Product } from '../../lib/types';

interface RuleFormProps {
  onSave: (rule: Omit<Rule, 'id' | 'createdAt' | 'updatedAt'>) => void;
  initialRule?: Rule;
}

export function RuleForm({ onSave, initialRule }: RuleFormProps) {
  const [name, setName] = useState(initialRule?.name || '');
  const [active, setActive] = useState(initialRule?.active ?? true);
  const [triggerProducts, setTriggerProducts] = useState<Product[]>(initialRule?.triggerProducts || []);
  const [freeProducts, setFreeProducts] = useState<Product[]>(initialRule?.freeProducts || []);
  const [minQuantity, setMinQuantity] = useState(initialRule?.minQuantity || 1);
  const [startDate, setStartDate] = useState<string | undefined>(
    initialRule?.startDate ? new Date(initialRule.startDate).toISOString().split('T')[0] : undefined
  );
  const [endDate, setEndDate] = useState<string | undefined>(
    initialRule?.endDate ? new Date(initialRule.endDate).toISOString().split('T')[0] : undefined
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    onSave({
      name,
      active,
      triggerProducts,
      freeProducts,
      minQuantity,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
    });
  };

  const handleAddTriggerProduct = (product: Product) => {
    setTriggerProducts([...triggerProducts, product]);
  };

  const handleRemoveTriggerProduct = (productId: string) => {
    setTriggerProducts(triggerProducts.filter(p => p.id !== productId));
  };

  const handleAddFreeProduct = (product: Product) => {
    setFreeProducts([...freeProducts, product]);
  };

  const handleRemoveFreeProduct = (productId: string) => {
    setFreeProducts(freeProducts.filter(p => p.id !== productId));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700">
          Nome da Regra
        </label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
      </div>

      <div>
        <label className="flex items-center">
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => setActive(e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
          />
          <span className="ml-2 text-sm text-gray-700">Ativo</span>
        </label>
      </div>

      <div>
        <label htmlFor="minQuantity" className="block text-sm font-medium text-gray-700">
          Quantidade Mínima
        </label>
        <input
          type="number"
          id="minQuantity"
          value={minQuantity}
          onChange={(e) => setMinQuantity(parseInt(e.target.value))}
          min="1"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">
            Data de Início (opcional)
          </label>
          <input
            type="date"
            id="startDate"
            value={startDate || ''}
            onChange={(e) => setStartDate(e.target.value || undefined)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">
            Data de Término (opcional)
          </label>
          <input
            type="date"
            id="endDate"
            value={endDate || ''}
            onChange={(e) => setEndDate(e.target.value || undefined)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          />
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium text-gray-900">Produtos Qualificadores</h3>
        <p className="text-sm text-gray-500">
          Selecione os produtos que, quando adicionados ao carrinho, ativarão a promoção.
        </p>
        
        {/* Aqui seria implementado um seletor de produtos da loja */}
        <div className="mt-2 border rounded-md p-4">
          {triggerProducts.length === 0 ? (
            <p className="text-sm text-gray-500">Nenhum produto selecionado</p>
          ) : (
            <ul className="divide-y divide-gray-200">
              {triggerProducts.map((product) => (
                <li key={product.id} className="py-2 flex justify-between items-center">
                  <span>{product.title}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveTriggerProduct(product.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    Remover
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium text-gray-900">Produtos Gratuitos</h3>
        <p className="text-sm text-gray-500">
          Selecione os produtos que serão adicionados automaticamente como brinde.
        </p>
        
        {/* Aqui seria implementado um seletor de produtos da loja */}
        <div className="mt-2 border rounded-md p-4">
          {freeProducts.length === 0 ? (
            <p className="text-sm text-gray-500">Nenhum produto selecionado</p>
          ) : (
            <ul className="divide-y divide-gray-200">
              {freeProducts.map((product) => (
                <li key={product.id} className="py-2 flex justify-between items-center">
                  <span>{product.title}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveFreeProduct(product.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    Remover
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          Salvar Regra
        </button>
      </div>
    </form>
  );
}
