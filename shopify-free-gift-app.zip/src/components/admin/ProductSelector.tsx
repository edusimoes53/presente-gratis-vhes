import { Rule, Product } from '../../lib/types';
import { useState, useEffect } from 'react';

interface ProductSelectorProps {
  onSelect: (product: Product) => void;
  selectedProductIds?: string[];
  title: string;
}

export function ProductSelector({ onSelect, selectedProductIds = [], title }: ProductSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Simula a busca de produtos na loja
  // Em um app real, isso seria conectado à API Shopify
  const searchProducts = async (term: string) => {
    if (!term.trim()) {
      setSearchResults([]);
      return;
    }

    setIsLoading(true);
    
    // Simulação de delay de rede
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Produtos de exemplo
    const mockProducts: Product[] = [
      { id: '1', title: 'Camiseta Básica', handle: 'camiseta-basica', variantId: '101', price: 49.90 },
      { id: '2', title: 'Calça Jeans', handle: 'calca-jeans', variantId: '201', price: 129.90 },
      { id: '3', title: 'Tênis Casual', handle: 'tenis-casual', variantId: '301', price: 199.90 },
      { id: '4', title: 'Boné Esportivo', handle: 'bone-esportivo', variantId: '401', price: 39.90 },
      { id: '5', title: 'Meia Kit com 3 pares', handle: 'meia-kit', variantId: '501', price: 29.90 },
    ];
    
    // Filtra produtos que correspondem ao termo de busca
    const filteredProducts = mockProducts.filter(
      product => product.title.toLowerCase().includes(term.toLowerCase())
    );
    
    setSearchResults(filteredProducts);
    setIsLoading(false);
  };

  useEffect(() => {
    const delaySearch = setTimeout(() => {
      searchProducts(searchTerm);
    }, 300);

    return () => clearTimeout(delaySearch);
  }, [searchTerm]);

  return (
    <div className="mt-4">
      <h3 className="text-lg font-medium text-gray-900">{title}</h3>
      <div className="mt-2">
        <input
          type="text"
          placeholder="Buscar produtos..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
      </div>
      
      {isLoading ? (
        <div className="mt-2 text-sm text-gray-500">Buscando produtos...</div>
      ) : searchResults.length > 0 ? (
        <ul className="mt-2 divide-y divide-gray-200 border rounded-md">
          {searchResults.map((product) => {
            const isSelected = selectedProductIds.includes(product.id);
            return (
              <li 
                key={product.id} 
                className={`p-3 flex justify-between items-center cursor-pointer hover:bg-gray-50 ${
                  isSelected ? 'bg-indigo-50' : ''
                }`}
                onClick={() => !isSelected && onSelect(product)}
              >
                <div>
                  <p className="font-medium text-gray-900">{product.title}</p>
                  <p className="text-sm text-gray-500">R$ {product.price?.toFixed(2)}</p>
                </div>
                <button
                  type="button"
                  disabled={isSelected}
                  className={`px-3 py-1 text-sm rounded-md ${
                    isSelected
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200'
                  }`}
                >
                  {isSelected ? 'Selecionado' : 'Selecionar'}
                </button>
              </li>
            );
          })}
        </ul>
      ) : searchTerm ? (
        <div className="mt-2 text-sm text-gray-500">Nenhum produto encontrado</div>
      ) : null}
    </div>
  );
}
