import { useState } from 'react';
import { Rule } from '../../lib/types';

interface RuleListProps {
  rules: Rule[];
  onEdit: (rule: Rule) => void;
  onDelete: (ruleId: string) => void;
  onToggleActive: (ruleId: string, active: boolean) => void;
}

export function RuleList({ rules, onEdit, onDelete, onToggleActive }: RuleListProps) {
  return (
    <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
      <table className="min-w-full divide-y divide-gray-300">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
              Nome
            </th>
            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
              Status
            </th>
            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
              Qtd. Mínima
            </th>
            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
              Produtos Qualificadores
            </th>
            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
              Brindes
            </th>
            <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
              Período
            </th>
            <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
              <span className="sr-only">Ações</span>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 bg-white">
          {rules.length === 0 ? (
            <tr>
              <td colSpan={7} className="px-3 py-4 text-sm text-gray-500 text-center">
                Nenhuma regra encontrada. Crie uma nova regra para começar.
              </td>
            </tr>
          ) : (
            rules.map((rule) => (
              <tr key={rule.id}>
                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                  {rule.name}
                </td>
                <td className="whitespace-nowrap px-3 py-4 text-sm">
                  <span
                    className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                      rule.active
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {rule.active ? 'Ativo' : 'Inativo'}
                  </span>
                </td>
                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                  {rule.minQuantity}
                </td>
                <td className="px-3 py-4 text-sm text-gray-500">
                  {rule.triggerProducts.map(p => p.title).join(', ')}
                </td>
                <td className="px-3 py-4 text-sm text-gray-500">
                  {rule.freeProducts.map(p => p.title).join(', ')}
                </td>
                <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                  {rule.startDate && rule.endDate
                    ? `${new Date(rule.startDate).toLocaleDateString()} - ${new Date(rule.endDate).toLocaleDateString()}`
                    : rule.startDate
                    ? `A partir de ${new Date(rule.startDate).toLocaleDateString()}`
                    : rule.endDate
                    ? `Até ${new Date(rule.endDate).toLocaleDateString()}`
                    : 'Sem período definido'}
                </td>
                <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                  <button
                    onClick={() => onToggleActive(rule.id, !rule.active)}
                    className="text-indigo-600 hover:text-indigo-900 mr-4"
                  >
                    {rule.active ? 'Desativar' : 'Ativar'}
                  </button>
                  <button
                    onClick={() => onEdit(rule)}
                    className="text-indigo-600 hover:text-indigo-900 mr-4"
                  >
                    Editar
                  </button>
                  <button
                    onClick={() => onDelete(rule.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Excluir
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export function RuleListPage() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [currentRule, setCurrentRule] = useState<Rule | undefined>(undefined);

  // Aqui seriam implementadas as funções para carregar, salvar, editar e excluir regras
  // usando a API Shopify

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-xl font-semibold text-gray-900">Regras de Promoção</h1>
          <p className="mt-2 text-sm text-gray-700">
            Configure as regras para adicionar automaticamente produtos gratuitos ao carrinho.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
          <button
            type="button"
            onClick={() => {
              setCurrentRule(undefined);
              setIsFormOpen(true);
            }}
            className="inline-flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:w-auto"
          >
            Nova Regra
          </button>
        </div>
      </div>
      <div className="mt-8">
        <RuleList
          rules={rules}
          onEdit={(rule) => {
            setCurrentRule(rule);
            setIsFormOpen(true);
          }}
          onDelete={(ruleId) => {
            // Implementar lógica de exclusão
            setRules(rules.filter(r => r.id !== ruleId));
          }}
          onToggleActive={(ruleId, active) => {
            // Implementar lógica de ativação/desativação
            setRules(
              rules.map(r => (r.id === ruleId ? { ...r, active } : r))
            );
          }}
        />
      </div>
    </div>
  );
}
