import { useState, useEffect } from 'react';
import { Rule } from '../../lib/types';
import { RuleForm } from './RuleForm';
import { RuleList } from './RuleList';
import { ProductSelector } from './ProductSelector';

export function AdminDashboard() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [currentRule, setCurrentRule] = useState<Rule | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  // Carregar regras existentes
  useEffect(() => {
    // Em um app real, isso buscaria as regras da API Shopify
    // Simulação para fins de demonstração
    const loadRules = async () => {
      setIsLoading(true);
      
      // Simulação de delay de rede
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Regras de exemplo
      const mockRules: Rule[] = [
        {
          id: '1',
          name: 'Compre 2 Camisetas, Ganhe 1 Boné',
          active: true,
          triggerProducts: [
            { id: '1', title: 'Camiseta Básica', handle: 'camiseta-basica' }
          ],
          freeProducts: [
            { id: '4', title: 'Boné Esportivo', handle: 'bone-esportivo' }
          ],
          minQuantity: 2,
          createdAt: new Date('2025-04-20'),
          updatedAt: new Date('2025-04-20')
        },
        {
          id: '2',
          name: 'Compre 1 Calça, Ganhe 1 Kit de Meias',
          active: false,
          triggerProducts: [
            { id: '2', title: 'Calça Jeans', handle: 'calca-jeans' }
          ],
          freeProducts: [
            { id: '5', title: 'Meia Kit com 3 pares', handle: 'meia-kit' }
          ],
          minQuantity: 1,
          startDate: new Date('2025-05-01'),
          endDate: new Date('2025-05-31'),
          createdAt: new Date('2025-04-15'),
          updatedAt: new Date('2025-04-15')
        }
      ];
      
      setRules(mockRules);
      setIsLoading(false);
    };
    
    loadRules();
  }, []);

  // Salvar uma nova regra ou atualizar uma existente
  const handleSaveRule = (ruleData: Omit<Rule, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (currentRule) {
      // Atualizar regra existente
      const updatedRules = rules.map(rule => 
        rule.id === currentRule.id 
          ? { 
              ...rule, 
              ...ruleData, 
              updatedAt: new Date() 
            } 
          : rule
      );
      setRules(updatedRules);
    } else {
      // Criar nova regra
      const newRule: Rule = {
        id: Date.now().toString(), // Em um app real, o ID seria gerado pelo servidor
        ...ruleData,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      setRules([...rules, newRule]);
    }
    
    setIsFormOpen(false);
    setCurrentRule(undefined);
  };

  // Excluir uma regra
  const handleDeleteRule = (ruleId: string) => {
    if (confirm('Tem certeza que deseja excluir esta regra?')) {
      setRules(rules.filter(rule => rule.id !== ruleId));
    }
  };

  // Ativar/desativar uma regra
  const handleToggleActive = (ruleId: string, active: boolean) => {
    setRules(
      rules.map(rule => 
        rule.id === ruleId 
          ? { ...rule, active, updatedAt: new Date() } 
          : rule
      )
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          Free Gift Buy X Get Y - Painel de Administração
        </h1>
        <p className="mt-2 text-gray-600">
          Configure regras para adicionar automaticamente produtos gratuitos ao carrinho quando determinados critérios forem atendidos.
        </p>
      </div>

      {isFormOpen ? (
        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              {currentRule ? 'Editar Regra' : 'Nova Regra'}
            </h2>
            <button
              type="button"
              onClick={() => {
                setIsFormOpen(false);
                setCurrentRule(undefined);
              }}
              className="text-gray-500 hover:text-gray-700"
            >
              Cancelar
            </button>
          </div>
          
          <RuleForm
            onSave={handleSaveRule}
            initialRule={currentRule}
          />
        </div>
      ) : (
        <div className="mb-8">
          <button
            type="button"
            onClick={() => {
              setCurrentRule(undefined);
              setIsFormOpen(true);
            }}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Nova Regra
          </button>
        </div>
      )}

      {isLoading ? (
        <div className="text-center py-12">
          <p className="text-gray-500">Carregando regras...</p>
        </div>
      ) : (
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <RuleList
            rules={rules}
            onEdit={(rule) => {
              setCurrentRule(rule);
              setIsFormOpen(true);
            }}
            onDelete={handleDeleteRule}
            onToggleActive={handleToggleActive}
          />
        </div>
      )}
    </div>
  );
}
