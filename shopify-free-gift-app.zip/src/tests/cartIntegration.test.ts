import { useState } from 'react';
import { CartItem, Product, Rule } from '../lib/types';
import { processCartRules } from '../lib/ruleEngine';

describe('Cart Integration Tests', () => {
  // Produtos de exemplo
  const product1: Product = { id: '1', title: 'Camiseta', handle: 'camiseta', variantId: '101' };
  const product2: Product = { id: '2', title: 'Calça', handle: 'calca', variantId: '201' };
  const product3: Product = { id: '3', title: 'Boné', handle: 'bone', variantId: '301' };
  
  // Regra de exemplo: Compre 2 Camisetas, Ganhe 1 Boné
  const rule: Rule = {
    id: '1',
    name: 'Compre 2 Camisetas, Ganhe 1 Boné',
    active: true,
    triggerProducts: [product1],
    freeProducts: [product3],
    minQuantity: 2,
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  // Itens de carrinho de exemplo
  const cartItem1: CartItem = {
    id: 'cart1',
    productId: '1',
    variantId: '101',
    quantity: 1,
    price: 49.90,
    title: 'Camiseta'
  };
  
  const cartItem2: CartItem = {
    id: 'cart2',
    productId: '2',
    variantId: '201',
    quantity: 1,
    price: 99.90,
    title: 'Calça'
  };
  
  const freeGiftItem: CartItem = {
    id: 'cart3',
    productId: '3',
    variantId: '301',
    quantity: 1,
    price: 0,
    title: 'Boné',
    isFreeGift: true,
    appliedRuleId: '1'
  };
  
  test('processCartRules - Deve adicionar produto gratuito quando condições atendidas', () => {
    const items = [{ ...cartItem1, quantity: 2 }];
    const result = processCartRules(items, [rule]);
    
    expect(result.productsToAdd).toHaveLength(1);
    expect(result.productsToAdd[0].id).toBe(product3.id);
    expect(result.itemsToRemove).toHaveLength(0);
  });
  
  test('processCartRules - Não deve adicionar produto gratuito quando condições não atendidas', () => {
    const items = [cartItem1]; // Apenas 1 camiseta, regra requer 2
    const result = processCartRules(items, [rule]);
    
    expect(result.productsToAdd).toHaveLength(0);
    expect(result.itemsToRemove).toHaveLength(0);
  });
  
  test('processCartRules - Deve remover brinde quando condições não mais atendidas', () => {
    const items = [
      cartItem1, // Apenas 1 camiseta, regra requer 2
      freeGiftItem
    ];
    const result = processCartRules(items, [rule]);
    
    expect(result.productsToAdd).toHaveLength(0);
    expect(result.itemsToRemove).toHaveLength(1);
    expect(result.itemsToRemove[0]).toBe(freeGiftItem.id);
  });
  
  test('processCartRules - Deve processar múltiplas regras corretamente', () => {
    // Segunda regra: Compre 1 Calça, Ganhe 1 Camiseta
    const rule2: Rule = {
      id: '2',
      name: 'Compre 1 Calça, Ganhe 1 Camiseta',
      active: true,
      triggerProducts: [product2],
      freeProducts: [product1],
      minQuantity: 1,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const items = [cartItem2]; // 1 calça
    const result = processCartRules(items, [rule, rule2]);
    
    expect(result.productsToAdd).toHaveLength(1);
    expect(result.productsToAdd[0].id).toBe(product1.id);
    expect(result.itemsToRemove).toHaveLength(0);
  });
  
  test('processCartRules - Não deve processar regras inativas', () => {
    const inactiveRule = { ...rule, active: false };
    const items = [{ ...cartItem1, quantity: 2 }];
    const result = processCartRules(items, [inactiveRule]);
    
    expect(result.productsToAdd).toHaveLength(0);
    expect(result.itemsToRemove).toHaveLength(0);
  });
});
