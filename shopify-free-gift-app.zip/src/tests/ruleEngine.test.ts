import { Rule, CartItem, Product } from '../lib/types';
import { isRuleApplicable, getGiftProductsToAdd, getGiftItemsToRemove } from '../lib/ruleEngine';

describe('Rule Engine Tests', () => {
  // Produtos de exemplo
  const product1: Product = { id: '1', title: 'Camiseta', handle: 'camiseta', variantId: '101' };
  const product2: Product = { id: '2', title: 'Calça', handle: 'calca', variantId: '201' };
  const product3: Product = { id: '3', title: 'Boné', handle: 'bone', variantId: '301' };
  
  // Regra de exemplo: Compre 2 Camisetas, Ganhe 1 Boné
  const rule: Rule = {
    id: '1',
    name: 'Compre 2 Camisetas, Ganhe 1 Boné',
    active: true,
    triggerProducts: [product1],
    freeProducts: [product3],
    minQuantity: 2,
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  // Itens de carrinho de exemplo
  const cartItem1: CartItem = {
    id: 'cart1',
    productId: '1',
    variantId: '101',
    quantity: 1,
    price: 49.90,
    title: 'Camiseta'
  };
  
  const cartItem2: CartItem = {
    id: 'cart2',
    productId: '2',
    variantId: '201',
    quantity: 1,
    price: 99.90,
    title: 'Calça'
  };
  
  const freeGiftItem: CartItem = {
    id: 'cart3',
    productId: '3',
    variantId: '301',
    quantity: 1,
    price: 0,
    title: 'Boné',
    isFreeGift: true,
    appliedRuleId: '1'
  };
  
  test('isRuleApplicable - Regra não deve ser aplicável quando quantidade insuficiente', () => {
    const items = [cartItem1]; // Apenas 1 camiseta, regra requer 2
    expect(isRuleApplicable(items, rule)).toBe(false);
  });
  
  test('isRuleApplicable - Regra deve ser aplicável quando quantidade suficiente', () => {
    const items = [
      { ...cartItem1, quantity: 2 } // 2 camisetas, regra requer 2
    ];
    expect(isRuleApplicable(items, rule)).toBe(true);
  });
  
  test('isRuleApplicable - Regra deve ser aplicável com múltiplos itens do mesmo produto', () => {
    const items = [
      { ...cartItem1, quantity: 1 },
      { ...cartItem1, id: 'cart1b', quantity: 1 }
    ];
    expect(isRuleApplicable(items, rule)).toBe(true);
  });
  
  test('isRuleApplicable - Regra não deve ser aplicável se estiver inativa', () => {
    const inactiveRule = { ...rule, active: false };
    const items = [{ ...cartItem1, quantity: 2 }];
    expect(isRuleApplicable(items, inactiveRule)).toBe(false);
  });
  
  test('getGiftProductsToAdd - Deve retornar produtos gratuitos quando regra aplicável', () => {
    const items = [{ ...cartItem1, quantity: 2 }];
    const result = getGiftProductsToAdd(items, rule);
    expect(result).toEqual([product3]);
  });
  
  test('getGiftProductsToAdd - Não deve retornar produtos quando regra não aplicável', () => {
    const items = [cartItem1]; // Apenas 1 camiseta, regra requer 2
    const result = getGiftProductsToAdd(items, rule);
    expect(result).toEqual([]);
  });
  
  test('getGiftProductsToAdd - Não deve retornar produtos já adicionados como brinde', () => {
    const items = [
      { ...cartItem1, quantity: 2 },
      freeGiftItem
    ];
    const result = getGiftProductsToAdd(items, rule);
    expect(result).toEqual([]);
  });
  
  test('getGiftItemsToRemove - Deve identificar brindes a remover quando regra não mais aplicável', () => {
    const items = [
      cartItem1, // Apenas 1 camiseta, regra requer 2
      freeGiftItem
    ];
    const result = getGiftItemsToRemove(items, [rule]);
    expect(result).toEqual([freeGiftItem.id]);
  });
  
  test('getGiftItemsToRemove - Não deve remover brindes quando regra ainda aplicável', () => {
    const items = [
      { ...cartItem1, quantity: 2 },
      freeGiftItem
    ];
    const result = getGiftItemsToRemove(items, [rule]);
    expect(result).toEqual([]);
  });
});
