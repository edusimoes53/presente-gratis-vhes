import { Rule, CartItem, Product } from './types';

/**
 * Verifica se um carrinho atende às condições de uma regra de promoção
 * @param items Itens no carrinho
 * @param rule Regra a ser verificada
 * @returns true se a regra for aplicável, false caso contrário
 */
export function isRuleApplicable(items: CartItem[], rule: Rule): boolean {
  if (!rule.active) {
    return false;
  }

  // Verifica datas de validade da regra
  const now = new Date();
  if (rule.startDate && now < rule.startDate) {
    return false;
  }
  if (rule.endDate && now > rule.endDate) {
    return false;
  }

  // Verifica se há produtos qualificadores no carrinho
  const triggerProductIds = rule.triggerProducts.map(p => p.variantId || p.id);
  
  // Conta a quantidade total de produtos qualificadores no carrinho
  let totalQualifyingItems = 0;
  
  for (const item of items) {
    // Ignora itens que já são brindes
    if (item.isFreeGift) {
      continue;
    }
    
    // Verifica se o item é um produto qualificador
    const isQualifyingProduct = triggerProductIds.includes(item.variantId) || 
                               triggerProductIds.includes(item.productId);
    
    if (isQualifyingProduct) {
      totalQualifyingItems += item.quantity;
    }
  }
  
  // Verifica se a quantidade mínima foi atingida
  return totalQualifyingItems >= rule.minQuantity;
}

/**
 * Determina quais produtos gratuitos devem ser adicionados ao carrinho
 * @param items Itens atuais no carrinho
 * @param rule Regra a ser aplicada
 * @returns Array de produtos a serem adicionados como brindes
 */
export function getGiftProductsToAdd(items: CartItem[], rule: Rule): Product[] {
  // Verifica se a regra é aplicável
  if (!isRuleApplicable(items, rule)) {
    return [];
  }
  
  // Verifica quais produtos gratuitos já estão no carrinho como brindes desta regra
  const existingGiftIds = items
    .filter(item => item.isFreeGift && item.appliedRuleId === rule.id)
    .map(item => item.variantId || item.productId);
  
  // Retorna apenas os produtos gratuitos que ainda não foram adicionados
  return rule.freeProducts.filter(product => 
    !existingGiftIds.includes(product.variantId || product.id)
  );
}

/**
 * Identifica quais itens gratuitos devem ser removidos do carrinho
 * @param items Itens atuais no carrinho
 * @param rules Todas as regras ativas
 * @returns IDs dos itens que devem ser removidos
 */
export function getGiftItemsToRemove(items: CartItem[], rules: Rule[]): string[] {
  const itemsToRemove: string[] = [];
  
  // Encontra todos os itens que são brindes
  const giftItems = items.filter(item => item.isFreeGift);
  
  for (const giftItem of giftItems) {
    // Encontra a regra que adicionou este brinde
    const appliedRule = rules.find(rule => rule.id === giftItem.appliedRuleId);
    
    // Se a regra não existe mais ou não é mais aplicável, o brinde deve ser removido
    if (!appliedRule || !isRuleApplicable(items, appliedRule)) {
      itemsToRemove.push(giftItem.id);
    }
  }
  
  return itemsToRemove;
}

/**
 * Processa todas as regras e determina quais mudanças devem ser feitas no carrinho
 * @param items Itens atuais no carrinho
 * @param rules Todas as regras ativas
 * @returns Objeto com produtos a adicionar e itens a remover
 */
export function processCartRules(items: CartItem[], rules: Rule[]): {
  productsToAdd: Product[];
  itemsToRemove: string[];
} {
  let productsToAdd: Product[] = [];
  
  // Processa cada regra ativa
  for (const rule of rules) {
    if (rule.active) {
      const giftsToAdd = getGiftProductsToAdd(items, rule);
      productsToAdd = [...productsToAdd, ...giftsToAdd];
    }
  }
  
  // Identifica brindes que devem ser removidos
  const itemsToRemove = getGiftItemsToRemove(items, rules);
  
  return {
    productsToAdd,
    itemsToRemove
  };
}
