export interface Product {
  id: string;
  title: string;
  handle: string;
  variantId?: string;
  variantTitle?: string;
  price?: number;
  image?: string;
}

export interface Rule {
  id: string;
  name: string;
  active: boolean;
  triggerProducts: Product[];
  freeProducts: Product[];
  minQuantity: number;
  startDate?: Date;
  endDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface CartItem {
  id: string;
  productId: string;
  variantId: string;
  quantity: number;
  price: number;
  title: string;
  variantTitle?: string;
  image?: string;
  isFreeGift?: boolean;
  appliedRuleId?: string;
}

export interface Cart {
  id: string;
  items: CartItem[];
  totalPrice: number;
  totalItems: number;
}
