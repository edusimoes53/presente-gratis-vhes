import type { AppProps } from 'next/app';
import { useState, useEffect } from 'react';
import { Rule } from '../lib/types';
import { AdminDashboard } from '../components/admin/AdminDashboard';
import { CartManager } from '../components/cart/CartManager';
import '../styles/globals.css';

export default function App({ Component, pageProps }: AppProps) {
  const [rules, setRules] = useState<Rule[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Carregar regras ao inicializar o app
  useEffect(() => {
    // Em um app real, isso buscaria as regras da API Shopify
    // Simulação para fins de demonstração
    const loadRules = async () => {
      // Simulação de delay de rede
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Regras de exemplo
      const mockRules: Rule[] = [
        {
          id: '1',
          name: 'Compre 2 Camisetas, Ganhe 1 Boné',
          active: true,
          triggerProducts: [
            { id: '1', title: 'Camiseta Básica', handle: 'camiseta-basica' }
          ],
          freeProducts: [
            { id: '4', title: 'Boné Esportivo', handle: 'bone-esportivo' }
          ],
          minQuantity: 2,
          createdAt: new Date('2025-04-20'),
          updatedAt: new Date('2025-04-20')
        },
        {
          id: '2',
          name: 'Compre 1 Calça, Ganhe 1 Kit de Meias',
          active: false,
          triggerProducts: [
            { id: '2', title: 'Calça Jeans', handle: 'calca-jeans' }
          ],
          freeProducts: [
            { id: '5', title: 'Meia Kit com 3 pares', handle: 'meia-kit' }
          ],
          minQuantity: 1,
          startDate: new Date('2025-05-01'),
          endDate: new Date('2025-05-31'),
          createdAt: new Date('2025-04-15'),
          updatedAt: new Date('2025-04-15')
        }
      ];
      
      setRules(mockRules);
      setIsLoaded(true);
    };
    
    loadRules();
  }, []);

  // Determinar se estamos na interface de administração ou na loja
  const isAdmin = typeof window !== 'undefined' && window.location.pathname.includes('/admin');

  return (
    <>
      {isAdmin ? (
        // Renderizar o painel de administração
        <AdminDashboard />
      ) : (
        // Renderizar o componente da página atual com o gerenciador de carrinho
        <>
          <Component {...pageProps} />
          {isLoaded && <CartManager rules={rules.filter(rule => rule.active)} />}
        </>
      )}
    </>
  );
}
