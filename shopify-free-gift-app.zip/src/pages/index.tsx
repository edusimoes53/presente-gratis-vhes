import { useState } from 'react';
import { CartNotification } from '../components/cart/CartManager';

export default function Home() {
  const [notification, setNotification] = useState('');

  // Simulação de demonstração da funcionalidade
  const simulateAddToCart = () => {
    setNotification('Produto adicionado ao carrinho!');
    setTimeout(() => {
      setNotification('Você ganhou um brinde! Boné Esportivo foi adicionado ao seu carrinho.');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Free Gift Buy X Get Y
          </h1>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Demonstração da funcionalidade de adicionar brindes automaticamente ao carrinho
          </p>
        </div>

        <div className="mt-12 bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h2 className="text-lg leading-6 font-medium text-gray-900">
              Como funciona
            </h2>
            <div className="mt-2 max-w-xl text-sm text-gray-500">
              <p>
                Quando um cliente adiciona produtos específicos ao carrinho e atinge a quantidade mínima definida,
                o app adiciona automaticamente produtos gratuitos como brinde.
              </p>
            </div>
            <div className="mt-5">
              <button
                type="button"
                onClick={simulateAddToCart}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Simular Adição ao Carrinho
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h2 className="text-lg leading-6 font-medium text-gray-900">
              Regras de Exemplo
            </h2>
            <ul className="mt-2 divide-y divide-gray-200">
              <li className="py-4">
                <div className="flex items-center space-x-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      Compre 2 Camisetas, Ganhe 1 Boné
                    </p>
                    <p className="text-sm text-gray-500">
                      Quando o cliente adiciona 2 ou mais camisetas ao carrinho, um boné é adicionado automaticamente como brinde.
                    </p>
                  </div>
                  <div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Ativo
                    </span>
                  </div>
                </div>
              </li>
              <li className="py-4">
                <div className="flex items-center space-x-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      Compre 1 Calça, Ganhe 1 Kit de Meias
                    </p>
                    <p className="text-sm text-gray-500">
                      Quando o cliente adiciona uma calça ao carrinho, um kit de meias é adicionado automaticamente como brinde.
                    </p>
                  </div>
                  <div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      Inativo
                    </span>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {notification && <CartNotification message={notification} />}
    </div>
  );
}
